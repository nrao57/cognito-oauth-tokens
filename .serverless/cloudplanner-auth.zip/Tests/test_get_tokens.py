from auth import get_tokens

redirect_uri = 'REDIRECT_URI'
url = 'COGNITO_TOKENS_ENDPOINT'
client_id = 'CLIENT_ID'
client_secret = 'CLIENT_SECRET'


def test_get_tokens():
    return True
