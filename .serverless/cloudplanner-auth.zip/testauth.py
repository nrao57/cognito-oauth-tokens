﻿import os
os.environ["REDIRECT_URI"] = "http://localhost:3000/profile"
os.environ[
    "COGNITO_TOKENS_ENDPOINT"] = "https://cloudplanner.auth.us-east-1.amazoncognito.com/oauth2/token"
os.environ["CLIENT_ID"] = "5q785n67mu1sd8bbjuqj2pckj7"
os.environ[
    "CLIENT_SECRET"] = "1hv8cfgukdom2b3hbqjkjd632a03r9uhebmmv6ufmr4fuor9hkou"

from tokens.tokens import get_tokens

get_tokens(
    {
        'queryStringParameters': {
            'authorization_code': "259cadd6-f2a0-434d-92bb-27f24e28b061"
        }
    }, None)
